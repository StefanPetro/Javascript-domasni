function Story() {

     this.title = "lorem ipsum";
     this.description = "lorem ipsum longer";
     this.date = new Date();


} 