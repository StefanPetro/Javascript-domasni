var names = [
    "Vladimir",
    "David",
    "Zoran",
    "Elena",
    "Ivana",
    "Petko",
    "Stanko",
    "Stefan"
];

var eventNames = [

    "bul",
    "Shite",
    "Ajnc"
    
    
    ];