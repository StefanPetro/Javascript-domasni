function Event(name) {

   this.name = name;
   this.registeredUsers =[];
   this.description = "bla bla";
   this.date = new Date();
   

   //this.registerUser = function(target) {
    //this.registeredUsers.push(target);
//}

   


   //this.registerUser = function(){


    //var element = new Element(user);
    //this.registeredUsers.push(Element);
   //}

   //this.registerUser();
//}

}