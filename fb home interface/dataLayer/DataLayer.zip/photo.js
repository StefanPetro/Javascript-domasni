function ProfPhoto(isProfile) {

    this.url = "https://picsum.photos/200/300/?random";
    this.altText = "lorem ipsum";
    //this.isProfile = isProfile || false;
    this.isProfile = isProfile;

}

function Photo() {

    this.url = "https://picsum.photos/200/300/?random";
    this.altText = "lorem ipsum";

}