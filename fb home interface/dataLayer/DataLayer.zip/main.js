function main() {
    var socialNetwork = new SocialNetwork("BookFace");
    console.log(socialNetwork);
}

main();